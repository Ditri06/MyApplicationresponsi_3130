package com.example.myapplication.model

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapplication.R

class HomeFragment : Fragment() {
    private val notes = NoteRepository.notes
    private lateinit var noteAdapter: NoteAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)
        val fab: FloatingActionButton = view.findViewById(R.id.fab)

        noteAdapter = NoteAdapter(notes) { note ->
            val intent = Intent(activity, DetailActivity::class.java)
            intent.putExtra("title", note.title)
            intent.putExtra("content", note.content)
            intent.putExtra("priority", note.priority)
            startActivity(intent)
        }

        recyclerView.layoutManager = LinearLayoutManager(activity)
        recyclerView.adapter = noteAdapter

        fab.setOnClickListener {
            val intent = Intent(activity, AddNoteActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        noteAdapter.notifyDataSetChanged()
    }
}
