package com.example.myapplication.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import com.example.myapplication.model.Note
import com.example.myapplication.model.NoteRepository

class AddNoteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)

        // Inisialisasi komponen UI
        val etTitle = findViewById<EditText>(R.id.etTitle)
        val etContent = findViewById<EditText>(R.id.etContent)
        val rgPriority = findViewById<RadioGroup>(R.id.rgPriority)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnSave.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val content = etContent.text.toString().trim()

            // Cek input kosong
            if (title.isEmpty() || content.isEmpty()) {
                Toast.makeText(this, "Judul dan isi tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Cek apakah ada radio button yang dipilih
            val selectedId = rgPriority.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Pilih prioritas catatan!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Ambil teks dari radio button yang dipilih
            val selectedPriority = findViewById<RadioButton>(selectedId).text.toString()

            // Tambah catatan ke repository
            NoteRepository.noteList.add(Note(title, content, selectedPriority))

            Toast.makeText(this, "Catatan berhasil disimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
