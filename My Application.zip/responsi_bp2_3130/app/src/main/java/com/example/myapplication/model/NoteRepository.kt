package com.example.myapplication.model

object NoteRepository {
    val noteList = mutableListOf<Note>()
}

