package com.example.myapplication.model

object NoteRepository {
    val notes = ArrayList<Note>()
}
