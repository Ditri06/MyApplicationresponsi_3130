package com.example.catatanapp.ui

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.catatanapp.R

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val tvTitle = findViewById<TextView>(R.id.tvTitleDetail)
        val tvContent = findViewById<TextView>(R.id.tvContentDetail)
        val tvPriority = findViewById<TextView>(R.id.tvPriorityDetail)

        // Ambil data dari Intent
        val title = intent.getStringExtra("title")
        val content = intent.getStringExtra("content")
        val priority = intent.getStringExtra("priority")

        // Tampilkan ke UI
        tvTitle.text = title
        tvContent.text = content
        tvPriority.text = "Prioritas: $priority"
    }
}
