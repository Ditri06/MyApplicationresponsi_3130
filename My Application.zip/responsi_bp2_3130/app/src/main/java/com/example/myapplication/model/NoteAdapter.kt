package com.example.myapplication.model

class NoteAdapter {
    class NoteAdapter(private val notes: List<Note>, private val onClick: (Note) -> Unit) :
        RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
            val binding = ItemRowNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return NoteViewHolder(binding)
        }

        override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
            val note = notes[position]
            holder.bind(note)
        }

        override fun getItemCount(): Int = notes.size

        inner class NoteViewHolder(private val binding: ItemRowNoteBinding) :
            RecyclerView.ViewHolder(binding.root) {
            fun bind(note: Note) {
                binding.tvTitle.text = note.title
                binding.tvContent.text = note.content
                binding.tvPriority.text = note.priority
                binding.root.setOnClickListener { onClick(note) }
            }
        }
    }

}