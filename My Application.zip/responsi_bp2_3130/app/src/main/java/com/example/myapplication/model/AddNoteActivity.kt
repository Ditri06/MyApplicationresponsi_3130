package com.example.catatanapp.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.catatanapp.R
import com.example.catatanapp.data.Note
import com.example.catatanapp.data.NoteRepository

class AddNoteActivity : AppCompatActivity() {

    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText
    private lateinit var rgPriority: RadioGroup
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)

        // Inisialisasi komponen UI
        etTitle = findViewById(R.id.etTitle)
        etContent = findViewById(R.id.etContent)
        rgPriority = findViewById(R.id.rgPriority)
        btnSave = findViewById(R.id.btnSave)

        // Tombol simpan diklik
        btnSave.setOnClickListener { saveNote() }
    }

    private fun saveNote() {
        val title = etTitle.text.toString().trim()
        val content = etContent.text.toString().trim()

        // Validasi input
        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_empty_fields), Toast.LENGTH_SHORT).show()
            return
        }


        val selectedPriorityId = rgPriority.checkedRadioButtonId
        val priority = when (selectedPriorityId) {
            R.id.rbHigh -> getString(R.string.priority_high)
            R.id.rbNormal -> getString(R.string.priority_normal)
            R.id.rbLow -> getString(R.string.priority_low)
            else -> getString(R.string.priority_normal)
        }


        val newNote = Note(title, content, priority)
        NoteRepository.notes.add(newNote)

        Toast.makeText(this, getString(R.string.note_saved), Toast.LENGTH_SHORT).show()
        finish() // Kembali ke HomeFragment
    }
}
